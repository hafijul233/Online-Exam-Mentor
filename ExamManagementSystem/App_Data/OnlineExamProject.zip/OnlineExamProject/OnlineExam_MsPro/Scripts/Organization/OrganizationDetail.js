﻿

$(document).ready(function() {
    

});

$("#ClickButton").click(function() {
   // $(this).html("<button>Changed</button>");
   // $(this).html("Changed");

    $("#NameTextBoxDiv").html("<input type='text'/>");

});

